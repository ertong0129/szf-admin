# 大明传说 · 局域网联机

个人学习用本地服：大厅选服 + 游戏端 + Node/Python 服务端。朋友可在同一局域网各自开浏览器进同一服。

## 怎么开

Windows 解压后双击 `start.bat`。Mac 解压后双击 `大明传说.app`，或右键打开 `启动游戏.command`。

启动器会先起本地服，**等服务就绪再打开浏览器**（测试号 `demo` / `123456`）。登录页应显示 **v20260816z**，没有这个版本号就是旧包。没有 Node 时自动改用 Python。账号、角色、聊天、BOSS 都写在本机 `data/hongwu.db`（SQLite，表结构按 MySQL，以后可换库）。终端窗口不要关。

```bash
cd hongwu-legend
node server.js
```

启动后窗口会打印本机 `127.0.0.1` 和局域网 IP（如 `http://192.168.x.x:8088/`）。朋友用浏览器打开**局域网地址**，各自注册账号，选**同一服务器**即可同图见面。防火墙需放行 8088。组队/交易/摆摊请用 Node 服务端。

**走路：** 左键点斜视 3D 地面（黄圈落点并自动寻路）。局内按 **1280×800** 等比缩放，窗口更宽或更高时留边，界面不会被拉长。**M 地图**点场景名或「传送」免费瞬移，用来检阅全部地图（含副本）。**点右侧任务追踪**会跨图自动寻路并对话/打怪/采药。点其他玩家：组队、交易、加好友、密聊、跟随；非和平模式可 PK。旧档若卡在房子里，进游戏会自动拉到空地。

网上资料与创作者 demo 见 `docs/REFERENCES.md`。结论：原作是 Flash「3D 建模 + 2D 原画」斜视 ARPG；创作者公开的是 Erlang 学习服 [mgee](https://github.com/qingliangcn/mgee)，不是完整 3D 客户端。本目录用独立 WebGL 画布做 Three.js 斜视场景（房屋、树、立绘、血条、落点），对照该镜头。

## 直接下载

Windows 包 GitHub 直链（当前分支最新 zip）：

https://github.com/ertong0129/szf-admin/raw/cursor/hongwu-offline-legend-f2d5/hongwu-windows.zip

国内备用：

https://cdn.jsdelivr.net/gh/ertong0129/szf-admin@cursor/hongwu-offline-legend-f2d5/hongwu-windows.zip

https://gh-proxy.com/https://github.com/ertong0129/szf-admin/raw/cursor/hongwu-offline-legend-f2d5/hongwu-windows.zip

## 画面说明

**局内**立绘、对话半身像、头像、世界/国家地图、人物框和青玉面板，来自用户提供的公开资源目录（`viewUI` / `mingUI` / `smallMap` / `com/ui/npc/` 等，见 `assets/ingame/`）。登录壳仍用 `Main.swf` 同目录切图。SWF 整包没有打进仓库。

## 原作简析

[91wan《明朝传奇》](https://www.91wan.com/mccq/) 是广州明朝互动开发的 Flash ARPG 页游。官网与百科可核对到的核心包括：

- **背景**：玩家“穿越”到洪武元年，在大明三百年史与江湖之间成长。
- **职业**：战士（刀剑、血防）、射手（弓矢、远程）、侠客（扇、内功爆发）、医仙（杖、治疗）。
- **战斗**：点击移动的即时战斗；和平 / 全体 / 组队 / 宗族 / 国家 / 善恶等 PK 模式。
- **养成**：属性加点（力 / 智 / 敏 / 精 / 体）、技能树、装备品质（白绿蓝紫橙）、天工炉强化 / 开孔 / 镶嵌灵石、宠物洗灵提悟。
- **日常循环**：自动挂机与自动寻路、主线与循环任务、鄱阳湖等副本、个人 / 宗族押镖、商贸、国战与王座争霸。

原作依赖 Flash，现代浏览器已无法直接进入。完整 MMO（跨服、交易行、宗族国战）也不适合原样搬进单机。

## 单机志范围

本目录实现一条可闭环的单人路线：

| 系统 | 单机实现 |
| --- | --- |
| 四职业即时战斗 | 战士 / 射手 / 侠客 / 医仙，普攻 + 6 个技能 |
| 挂机 | Z 键自动寻敌、放技能、吃药、拾取 |
| 地图 | 太平村、野猪林、神农谷、鄱阳水寨、应天京城、官道押镖、英雄试炼 |
| 养成 | 装备升星开孔镶石；坐骑六件套（马铠、马鞍、马饰、马缰、马镫、马蹄），穿上绑定 |
| 灵宠 | 神农谷收服或向驯兽师请一只，随行攻击 |
| 功业 | 11 条主线。开封有步步惊心、深宫谍影、开封铁塔 |
| 货币 | 银两/元宝/道具均分绑定与不绑定。商店购得绑定；打怪掉落不绑定 |
| 存档 | 本机 `data/hongwu.db`（SQLite）。浏览器不存档。以后可把 `DB_DRIVER` 改成 mysql |

未做：真实支付网关、开箱子、跨服战场、国战。元宝与明朝贵族为局内银两兑换，局域网不接充值平台。

## 操作

- **WASD / 方向键** 移动，鼠标左键点地寻路、点敌人锁定、点 NPC 对话
- **点右侧任务追踪**（或功业面板「寻路」）自动寻路：跨图会先走到传送点，对话任务到达后自动交谈，击杀/采集会锁定最近目标
- **1–6** 技能，**空格** 普攻，**Q / R** 吃药，**F** 拾取，**Z** 挂机
- 底栏右侧红钮 **商** 打开商城；小地图可点击走路
- **C** 角色 **B** 背包 **V** 技能 **P** 灵宠 **E** 百工炉 **J** 任务 **Esc** 关窗
- 背包左键使用或装备，右键丢弃

## 测试

```bash
node hongwu-legend/tests/store.test.js
node hongwu-legend/tests/formulas.test.js
node hongwu-legend/tests/path.test.js
node hongwu-legend/tests/server-http.test.js
```
